 
#ifndef __COMMON__STRING_H
    #define __COMMON__STRING_H
    
    namespace kayos
    {
        namespace common
        {
            
            typedef const char* string;
            
        }        
    }
    
#endif