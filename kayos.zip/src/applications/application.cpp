
#include<applications/application.h>

namespace kayos
{
    namespace applications
    {
        
        Application::Application()
         :  GraphicalObject()
        {

        }

        Application::~Application()
        {
        }

    }
}

