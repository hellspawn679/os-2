 
#include<drivers/rawdatahandler.h>

namespace kayos
{
    namespace drivers
    {
        
        RawDataHandler::RawDataHandler()
        {
        }
        
        RawDataHandler::~RawDataHandler()
        {
        }
        
        bool RawDataHandler::HandleRawData(uint8_t*, uint32_t)
        {
            return false;
        }
        
    }
}
